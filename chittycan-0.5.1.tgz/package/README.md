![ChittyOS](https://img.shields.io/badge/ChittyOS-service-6366F1?style=flat-square)
![Tier](https://img.shields.io/badge/tier-3%20operational-3730A3?style=flat-square)

# ChittyCan

> **chittycan learn. chittycan evolve. chittycan remember.**
>
> **chitty can, if you can.**

[![OpenAI Compatible](https://img.shields.io/badge/OpenAI-Compatible-green?logo=openai)](docs/benchmark-results.md)
[![Tests](https://img.shields.io/github/actions/workflow/status/chittycorp/chittycan/parity-tests.yml?branch=main&label=parity%20tests)](https://github.com/chittycorp/chittycan/actions)
[![npm version](https://img.shields.io/npm/v/chittycan)](https://www.npmjs.com/package/chittycan)
[![License: MIT](https://img.shields.io/badge/License-MIT-blue.svg)](LICENSE)

Your completely autonomous network that **grows with you**—learning your patterns, evolving your workflow, and remembering your context across every session.

## 🎯 NEW: Your CLI Solution Provider (v0.4.3)

**Stop memorizing syntax. Start speaking naturally.**

ChittyCan now translates plain English into perfect CLI commands for GitHub, Docker, Kubernetes, and 14+ other tools.

```bash
# No quotes needed—just type naturally
can gh clone my repo
can docker list running containers
can kubectl get pods in production
```

**Learn more:** [can.mychitty.com](https://can.mychitty.com) | [mychitty.com/can](https://mychitty.com/can)

### The Evolution: From Asking to Commanding

1. **Beginner**: `can chitty gh clone repo` (guided, explicit)
2. **Intermediate**: `can gh clone repo` (direct, confident)
3. **Advanced**: System learns your patterns and personalizes itself

### What You Get

- 💬 **Natural Language** - Speak in plain English, no syntax memorization
- 🎯 **14+ CLIs Supported** - gh, docker, kubectl, git, aws, gcloud, terraform, and more
- 🧠 **Learns Your Patterns** - Tracks usage, suggests commands, grows with you
- 🔧 **Custom Workflows** - `can chitty start coffee` → triggers your coffee machine
- ✅ **Guided Setup** - Checks installation, auth, and walks you through configuration
- 📊 **Usage Insights** - `can chitty insights` shows your patterns

[See full CLI Solution Provider docs →](docs/MYCHITTY_PROMO.md)

---

## 🛠️ Complete Development Workflow

ChittyCan is a unified command-line tool that helps you manage every aspect of your development workflow:

- 📋 **Project Tracking** - Sync between Notion databases and GitHub Projects
- ☁️ **Cloud Infrastructure** - Manage Cloudflare Workers, DNS, KV, R2, Durable Objects
- 🗄️ **Database Management** - Neon PostgreSQL schemas, migrations, and deployments
- 🤖 **AI Tools** - Configure MCP servers and Claude Code settings
- 📁 **File Management** - Organize Google Drive and rclone remotes
- ⏱️ **Smart Nudges** - Shell hooks remind you to update trackers after git commits
- 🔄 **Two-Way Sync** - Keep Notion Actions and GitHub Issues in perfect sync

## Quick Start

```bash
# Install globally
npm install -g chittycan

# Or run directly
npx chittycan

# Initialize with interactive config
can config
```

## 🧠 Philosophy: Grow With Me

ChittyCan is built on a simple but powerful idea: **your tools should learn from you, not the other way around.**

It establishes your **ChittyDNA**—a living blueprint of how you work, what you prefer, and how you create.

### chittycan learn
Every command you run, every pattern you create, every preference you express—ChittyCan observes and learns. Over time, it understands how you work and encodes it into your **ChittyDNA**.

### chittycan evolve
ChittyCan doesn't stay static. It adapts to your changing workflow, suggests optimizations, and grows more intelligent with each interaction—evolving your **ChittyDNA** as you grow.

### chittycan remember
Context is preserved across sessions. ChittyCan remembers what you accomplished, what you configured, and what you prefer—your **ChittyDNA** persists, so you never start from scratch.

### chitty can, if you can
You define the possibilities. ChittyCan amplifies your capabilities—learning your patterns, automating the repetitive, and scaling with your ambitions.

**The result?** A tool that becomes more powerful the longer you use it. Not through manual configuration, but through intelligent observation and evolution.

**ChittyDNA** means:
- Your workflow patterns are automatically recognized
- Your tool preferences inform smart routing decisions
- Your project context is preserved across sessions
- Your automation evolves with your needs
- Your productivity compounds over time

ChittyCan doesn't just remember commands—it understands **you**.

---

## 🏛️ Foundation Governance

ChittyCan operates under the **[ChittyFoundation Charter v0.1](FOUNDATION.md)** - a comprehensive framework that protects human dignity, ownership, and fairness in AI systems.

### You Own Your DNA

Your ChittyDNA belongs to **you**, not to ChittyCan. We obtain a scoped, revocable license—but you retain full ownership rights.

**This means:**
- ✅ **Export Anytime:** Your DNA is portable in PDX (Portable DNA eXchange) format
- ✅ **Revoke Access:** You can revoke ChittyCan's license and delete your DNA
- ✅ **Privacy with Proof:** We log hashes, not content—provable without exposure
- ✅ **Attribution Chains:** If we monetize, you get loyalty-based compensation for your DNA
- ✅ **Ethical Exit:** If we violate Foundation values, your exit rights activate immediately

### ChittyCertified Roadmap

ChittyCan is pursuing **ChittyCertified** status in three tiers:

| Tier | Target | Status | Key Features |
|------|--------|--------|--------------|
| **Bronze** | v0.5.0 (Q1 2025) | 🟡 In Progress | DNA vaults, PDX export/import, privacy-preserving audits |
| **Silver** | v0.6.0 (Q2 2025) | 🔴 Planned | Attribution chains, fair-pay metrics, cross-platform DNA |
| **Gold** | v0.7.0 (Q3 2025) | 🔴 Planned | Zero-knowledge proofs, AI caretakers, global compliance |

### Foundation Principles

ChittyCan adheres to these non-negotiable principles:

1. **You Own Your Data & DNA** - Individuals own their decision patterns; orgs obtain licenses, not ownership
2. **Portability by Default** - Export, revoke, and migrate are baseline rights
3. **Attribution → Compensation** - Traceable contributions map to loyalty-based compensation
4. **Privacy with Proof** - Content can remain private while proofs remain verifiable
5. **Human Safety & Dignity** - No surveillance abuse, coercion, or harm
6. **Transparency over Theater** - Decisions and metrics are explainable and auditable
7. **Diversity as Resilience** - Multi-provider support prevents vendor lock-in

### Learn More

- **[Foundation Compliance Document](FOUNDATION.md)** - Complete compliance roadmap
- **[PDX Specification](PDX_SPEC.md)** - Technical spec for DNA portability
- **[ChittyFoundation Charter](https://foundation.chitty.cc/charter)** - Full governance framework

---

## 🚀 AI Gateway (New in v0.4.0!)

**ChittyCan is now an OpenAI-compatible AI gateway** - a drop-in replacement for OpenAI API that routes your requests through 8+ AI platforms with intelligent fallback chains, caching, and budget controls.

### Why Use ChittyCan Gateway?

- **💰 Cost Optimization** - Route requests to cheapest provider, cache responses, set budget limits
- **🔄 Smart Fallback** - If one provider fails, automatically try the next in your chain
- **🛡️ Resilience** - Never get blocked by a single provider's outage
- **📊 Unified Interface** - One API for OpenAI, Anthropic, Ollama, Groq, and more
- **🔒 Self-Hosted** - Run your own gateway, keep your API keys private
- **⚡ Intelligent Routing** - Route based on model capabilities, cost, or latency

### Quick Migration from OpenAI

```python
# Before (direct OpenAI)
import openai
openai.api_key = "sk-..."
response = openai.ChatCompletion.create(model="gpt-4", ...)

# After (ChittyCan gateway)
import openai
openai.api_base = "http://localhost:8787/v1"  # Your ChittyCan gateway
openai.api_key = "your-chittycan-token"
response = openai.ChatCompletion.create(model="gpt-4", ...)  # Works identically!
```

**That's it!** Your existing code works unchanged. See [MIGRATION_PLAYBOOK.md](docs/MIGRATION_PLAYBOOK.md) for full guide.

### Gateway Configuration

```bash
# Configure AI gateway
can config

# Choose: New remote → AI Platform
# Select platform:
#   1 / OpenAI       - GPT-4, GPT-3.5, DALL-E
#   2 / Anthropic    - Claude Sonnet, Opus, Haiku
#   3 / Ollama       - Local models (Llama, Mistral, etc)
#   4 / Groq         - Ultra-fast inference
#   5 / Replicate    - Open source models
#   6 / Together     - Inference API
#   7 / HuggingFace  - 100k+ models
#   8 / Cohere       - Command, Embed models

# Configure gateway tier:
# - Free: 1000 req/day, basic caching
# - Pro: Unlimited, smart routing, fallback chains
# - Team: Multi-user, usage analytics
# - Enterprise: Self-hosted, SLA, support
```

### Gateway Features by Tier

| Feature | Free | Pro | Team | Enterprise |
|---------|------|-----|------|------------|
| Requests/day | 1,000 | Unlimited | Unlimited | Unlimited |
| Basic Caching | ✅ | ✅ | ✅ | ✅ |
| Smart Routing | ❌ | ✅ | ✅ | ✅ |
| Fallback Chains | ❌ | ✅ | ✅ | ✅ |
| Budget Controls | ❌ | ✅ | ✅ | ✅ |
| Usage Analytics | ❌ | ❌ | ✅ | ✅ |
| Multi-user | ❌ | ❌ | ✅ | ✅ |
| Self-hosted | ❌ | ❌ | ❌ | ✅ |
| SLA & Support | ❌ | ❌ | ❌ | ✅ |

**Pricing:** Free tier available. Pro $29/mo, Team $99/mo, Enterprise contact sales.

### Parity Testing

ChittyCan maintains **100% OpenAI API compatibility**. We test every endpoint:

```bash
# Run parity tests
export CHITTYCAN_TOKEN=your_token
export OPENAI_API_BASE=http://localhost:8787/v1
npm run test:parity
```

See [tests/parity_py.py](tests/parity_py.py) and [tests/parity_node.js](tests/parity_node.js) for test suite.

**Report compatibility issues:** Use the [Parity Failure](https://github.com/chittycorp/chittycan/issues/new?template=parity_failure.yml) issue template - we fix within 24 hours.

## Natural Language Commands

ChittyCan supports natural language for 14+ popular CLIs. Just tell it what you want in plain English (quotes optional):

```bash
# GitHub CLI
can gh create a PR for my bug fix
can gh list all my open issues
can gh clone the repo chittyapps/chittycan

# Docker
can docker list all running containers
can docker stop the nginx container
can docker show logs for app container

# Git
can git commit all changes with message fixed auth
can git create a new branch called feature/login

# Kubernetes
can kubectl get all pods in production namespace
can kubectl scale my deployment to 3 replicas

# Quotes work too (useful for preserving exact phrasing)
can gh "create a PR titled 'Fix: auth bug'"
can git "commit everything with message 'v2.0 release'"

# And more: npm, aws, gcloud, az, terraform, helm, cargo, pip, yarn, pnpm
```

**How it works:** ChittyCan proxies natural language commands to the full [chitty CLI](https://github.com/chittyos/cli), which uses AI to interpret and execute the actual commands.

**Note:** Natural language commands require the full `chitty` CLI. If not installed, ChittyCan shows upgrade instructions.

## Core Features

### 1. Project Tracking

Interactive `rclone`-style config for managing "remotes" (Notion databases, GitHub projects):

```bash
# Open interactive config menu
can config

# Add a Notion database remote
# Choose: New remote → Notion database
# Enter your database URL: https://notion.so/DATABASE_ID?v=VIEW_ID

# Add a GitHub project remote
# Choose: New remote → GitHub project

# List all remotes
can remote list

# Open a remote
can open tracker
can open tracker actions  # Open specific view
```

### 2. Smart Shell Hooks

Get reminded to update your tracker after important commands:

```bash
# Install zsh hooks
can hook install zsh

# Now you'll get nudges after:
# - git commit
# - git merge
# - wrangler deploy
# - npm publish

# Manual checkpoint
ai_checkpoint "Finished OAuth implementation"

# Press Ctrl-G to open tracker anytime
```

### 3. Two-Way Notion ↔ GitHub Sync

Keep your Notion Actions and GitHub Issues in perfect sync:

```bash
# Setup sync (interactive)
can sync setup

# Preview changes without applying
can sync run --dry-run

# Run sync
can sync run

# Check sync status
can sync status
```

**Mapping:**
- Notion Status "To Do" ↔ GitHub open + label:todo
- Notion Status "In Progress" ↔ GitHub open + label:in-progress
- Notion Status "Done" ↔ GitHub closed + label:done
- Notion Status "Archived" ↔ GitHub closed + label:archived

**Conflict Resolution:**
- Automatically detects when both Notion and GitHub changed
- Sets Sync State to "conflict" in Notion
- Manual resolution required

### 4. Cloud Infrastructure Management (Coming Soon)

```bash
# Cloudflare Workers
can cf worker list
can cf worker deploy chittyauth --env production
can cf worker tail chittyconnect
can cf worker secrets set chittyauth JWT_SECRET

# DNS
can cf dns list chitty.cc
can cf dns add chitty.cc A new-service 1.2.3.4

# KV / R2
can cf kv list --namespace CACHE
can cf r2 list --bucket documents
```

### 5. Database Management (Coming Soon)

```bash
# List databases
can neon db list

# Run migrations
can neon migrate up
can neon migrate down

# Schema diff
can neon schema diff production staging

# Quick query
can neon query "SELECT * FROM identities LIMIT 5"
```

### 6. MCP & AI Configuration (Coming Soon)

```bash
# List installed MCP servers
can mcp list

# Install a new MCP server
can mcp install @modelcontextprotocol/server-filesystem

# Configure Claude Code
can claude config
can claude remote add my-api https://api.example.com
```

### 7. Storage & Sync (Coming Soon)

```bash
# rclone integration
can rclone remote add gdrive
can rclone sync local:./docs gdrive:/ChittyOS/docs

# Google Drive organization
can gdrive tree
can gdrive mkdir "ChittyOS/Projects"
```

## Installation

### Global Installation

```bash
npm install -g chittycan
```

### Local Development

```bash
git clone https://github.com/YOUR_USERNAME/chittycan
cd chittycan
npm install
npm run build
npm link
```

## Configuration

All config is stored in `~/.config/chitty/config.json`:

```json
{
  "remotes": {
    "tracker": {
      "type": "notion-database",
      "url": "https://notion.so/DATABASE_ID?v=VIEW_ID",
      "databaseId": "DATABASE_ID",
      "views": {
        "actions": "https://notion.so/DATABASE_ID?v=VIEW_ID",
        "projects": "https://notion.so/DATABASE_ID?v=VIEW_ID"
      }
    },
    "chittyos": {
      "type": "github-project",
      "owner": "YOUR_USERNAME",
      "repo": "chittyos",
      "projectNumber": 1
    },
    "ai-gateway": {
      "type": "ai-platform",
      "platform": "openai",
      "apiKey": "sk-...",
      "model": "gpt-4",
      "gateway": {
        "accountId": "your-account-id",
        "gatewayId": "your-gateway-id",
        "enabled": true,
        "tier": "pro",
        "caching": true,
        "smartRouting": true,
        "fallbackChain": true,
        "budget": {
          "daily": 10,
          "monthly": 300
        },
        "oauth": {
          "enabled": true,
          "scopes": ["chat", "embeddings"],
          "openaiCompatible": true
        }
      }
    },
    "production": {
      "type": "cloudflare",
      "accountId": "your-cf-account",
      "apiToken": "your-cf-token",
      "workers": ["chittyauth", "chittyconnect"],
      "zones": ["chitty.cc"]
    },
    "database": {
      "type": "neon",
      "projectId": "your-project-id",
      "apiKey": "your-neon-key",
      "databases": ["chittyos-core"]
    },
    "server": {
      "type": "ssh",
      "host": "server.example.com",
      "user": "admin",
      "port": 22,
      "keyPath": "~/.ssh/id_rsa"
    },
    "claude": {
      "type": "mcp-server",
      "name": "@modelcontextprotocol/server-filesystem",
      "command": "npx",
      "args": ["-y", "@modelcontextprotocol/server-filesystem", "/path/to/files"]
    }
  },
  "nudges": {
    "enabled": true,
    "intervalMinutes": 45
  },
  "sync": {
    "enabled": true,
    "notionToken": "secret_...",
    "githubToken": "ghp_...",
    "mappings": [
      {
        "notionRemote": "tracker",
        "githubRemote": "chittyos"
      }
    ]
  }
}
```

### Supported Remote Types

- **notion-database** - Notion database for project tracking
- **github-project** - GitHub Projects v2
- **ai-platform** - AI gateway (OpenAI, Anthropic, Ollama, Groq, etc.) 🆕
- **cloudflare** - Cloudflare Workers, DNS, KV, R2 🆕
- **neon** - Neon PostgreSQL databases 🆕
- **ssh** - SSH remote servers 🆕
- **mcp-server** - Model Context Protocol servers 🆕
- **gdrive** - Google Drive (via rclone)
- **rclone** - Any rclone-supported remote

## Command Reference

### General

```bash
can config                    # Interactive config menu
can remote list               # List all remotes
can open <name> [view]        # Open remote in browser
```

### Tracking & Nudges

```bash
can nudge now                 # Interactive nudge
can nudge quiet               # Quick reminder
can checkpoint [message]      # Save checkpoint
can checkpoints [limit]       # List recent checkpoints
```

### Shell Hooks

```bash
can hook install zsh          # Install zsh hooks
can hook uninstall zsh        # Uninstall zsh hooks
```

### Sync

```bash
can sync setup                # Configure sync
can sync run [--dry-run]      # Run sync
can sync status               # Show sync config
```

## Setup Guides

### AI Gateway
- **[Migration Playbook](docs/MIGRATION_PLAYBOOK.md)** - Migrate from OpenAI to ChittyCan in 3 steps
- **[Competitive Analysis](docs/COMPETITIVE_ANALYSIS.md)** - How ChittyCan compares to alternatives
- **[Investor Pitch](docs/INVESTOR_PITCH.md)** - Business case and roadmap
- **[Tactical Roadmap](ROADMAP.md)** - What we're building and when

### Integration
- **[Multi-Model Architecture](docs/MULTI_MODEL.md)** - Pop any AI model at any juncture
- **[GitHub App Setup](docs/GITHUB_APP.md)** - Create GitHub App for webhooks and API access
- **[ChittyOS Integration](docs/CHITTYOS_INTEGRATION.md)** - Connect to ChittyOS ecosystem
- **[Extensions & Plugins](docs/EXTENSIONS.md)** - Extend ChittyCan functionality

### Documentation
- **[Quick Start Guide](docs/QUICKSTART.md)** - Get up and running in 5 minutes
- **[OS Support](docs/OS_SUPPORT.md)** - Platform compatibility
- **[Full Documentation](docs/)** - Complete documentation

### Contributing
- **[Contributing Guide](CONTRIBUTING.md)** - How to contribute code
- **[License Strategy](LICENSE_STRATEGY.md)** - AGPL v3 + Commercial licensing explained
- **[Code of Conduct](CODE_OF_CONDUCT.md)** - Community guidelines
- **[Security Policy](SECURITY.md)** - Report vulnerabilities

## Architecture

### CLI Structure

```
chittycan/
├── src/
│   ├── commands/          # Command implementations
│   │   ├── config.ts      # Interactive rclone-style config
│   │   ├── open.ts        # Open remotes
│   │   ├── nudge.ts       # Nudges and reminders
│   │   ├── checkpoint.ts  # Checkpoint logging
│   │   ├── hook.ts        # Shell hook management
│   │   └── sync.ts        # Two-way sync
│   ├── lib/               # Core libraries
│   │   ├── config.ts      # Config management
│   │   ├── notion.ts      # Notion API client
│   │   ├── github.ts      # GitHub API client
│   │   └── sync.ts        # Sync worker
│   ├── types/             # TypeScript types
│   └── zsh/               # Shell snippets
│       └── snippets.zsh   # Zsh hooks
├── bin/
│   └── can.js             # CLI entry point
└── tests/                 # Test suite
```

### Future: Web Interface

Coming soon - web dashboard for:
- Visual project status
- Sync history and conflicts
- Infrastructure monitoring
- AI usage analytics

### Future: MCP Server

Expose ChittyCan via Model Context Protocol:

```json
{
  "mcpServers": {
    "chittycan": {
      "command": "can",
      "args": ["mcp"]
    }
  }
}
```

## Development Roadmap

### v0.4.0: AI Gateway ✅ (Shipped!)
- [x] OpenAI-compatible AI gateway
- [x] 8 AI platform support (OpenAI, Anthropic, Ollama, Groq, etc.)
- [x] Gateway tier pricing (Free/Pro/Team/Enterprise)
- [x] Smart routing and fallback chains
- [x] Budget controls and caching
- [x] OAuth/API integration
- [x] Parity test suite (Python + Node.js)
- [x] Benchmark runner with Prometheus/Grafana
- [x] SSH, MCP Server, Cloudflare, Neon remote types

### v0.5.0: Production Hardening 🚧 (In Progress)
- [ ] Self-hosted gateway deployment guide
- [ ] Advanced fallback strategies (model-specific)
- [ ] Request/response logging and replay
- [ ] Cost tracking dashboard
- [ ] Multi-user token management
- [ ] **License change to AGPL v3** (with commercial option)

### v0.6.0: Cloud Infrastructure 📋
- [ ] Cloudflare Workers deployment automation
- [ ] DNS configuration wizard
- [ ] KV/R2 operations
- [ ] Neon database schema migrations
- [ ] Infrastructure as code export

### v0.7.0: Observability & Analytics 📋
- [ ] Web dashboard
- [ ] Real-time metrics (latency, cost, errors)
- [ ] Usage analytics per model/provider
- [ ] Budget alerts and notifications
- [ ] Historical data export

## Contributing

Contributions welcome! See [CONTRIBUTING.md](./CONTRIBUTING.md) for detailed guidelines.

**Quick start:**
1. Fork the repo
2. Create a feature branch
3. Make your changes
4. Add tests (maintain >80% coverage)
5. Run parity tests if touching API
6. Submit a PR

**Important:**
- First-time contributors must sign the CLA
- OpenAI API parity is critical - test everything
- Follow [Conventional Commits](https://www.conventionalcommits.org/)
- Report parity failures within 24 hours

## License

MIT

## Philosophy

**C.A.N. has dual meanings:**

1. **Chitty Autonomous Navigator** - Emphasizes autonomous navigation across platforms
2. **ChittyCan Completely Autonomous Network** - Emphasizes the self-managing networked ecosystem

**"Can you...?" → "Yes you can!"**

ChittyCan embodies the spirit of empowerment - it's your completely autonomous network that seamlessly navigates across platforms, managing infrastructure, syncing data, and keeping you productive. When someone asks "Can you manage my cloud infrastructure from the command line?" or "Can you keep my Notion and GitHub in sync?", the answer is always a confident **"Yes you can!"**

The name works on multiple levels:
- 🤖 **Completely Autonomous** - Smart nudges, auto-sync, proactive reminders, self-managing agents
- 🌐 **Network** - Interconnected ecosystem of ChittyOS services + 80+ external platforms
- 🧭 **Navigator** - Seamlessly moves between Notion, GitHub, Cloudflare, Neon, Linear, and more
- ✅ **Can** - Empowering affirmation that you can accomplish anything

## 🚀 Model-Agnostic Networked Async Workstream

**The killer feature:** You can pop **any AI model** at **any juncture** in your networked async workstream and it just works.

### Multi-Model Architecture

```
Your Workflow:
  ┌─────────────┐
  │   Task 1    │ ─── Claude Sonnet (code generation)
  └─────────────┘
         │
  ┌─────────────┐
  │   Task 2    │ ─── GPT-4 (analysis via ChittyConnect proxy)
  └─────────────┘
         │
  ┌─────────────┐
  │   Task 3    │ ─── Llama Scout (routing via ChittyRouter)
  └─────────────┘
         │
  ┌─────────────┐
  │   Task 4    │ ─── Claude Code (implementation)
  └─────────────┘
```

**Why this matters:**
- 🎯 **Right tool for the job** - Use the best model for each specific task
- 💰 **Cost optimization** - Cheap models for simple tasks, powerful models for complex ones
- 🔄 **No lock-in** - Switch providers without changing your workflow
- ⚡ **Async + Networked** - Models work on different tasks simultaneously across the network
- 🛡️ **Resilience** - If one model is down, fallback chain kicks in automatically

### Example: Multi-Model Legal Case Processing

```bash
# Step 1: ChittyRouter uses Llama Scout to triage incoming email
can router inbox process --agent triage

# Step 2: ChittyConnect proxies to GPT-4 for document analysis
can connect proxy openai "Analyze this contract for key terms"

# Step 3: Local Claude Code generates response
can router agent invoke response --email abc123 --draft

# Step 4: ChittyID mints credential with any available model
can id credential issue --type VerifiedDocument

# All working together in one async networked workflow ✨
```

### Supported Integration Points

**Any model can plug into:**
- 📧 **ChittyRouter agents** - Email triage, priority, response, document analysis
- 🔌 **ChittyConnect proxies** - OpenAI, Anthropic, local models
- 🤖 **MCP servers** - Claude Code, Claude Desktop, custom tools
- 📝 **Smart nudges** - Local AI suggesting what to update
- 🔄 **Sync engine** - AI-powered conflict resolution
- 🎯 **ChittyRegistry scripts** - Model-driven automation

## Related Projects

- **[ChittyOS](https://github.com/YOUR_USERNAME/chittyos)** - Legal technology platform
- **[ChittyID](https://id.chitty.cc)** - Identity service
- **[ChittyConnect](https://connect.chitty.cc)** - AI-intelligent integration spine

---

Built with ❤️ for the ChittyOS ecosystem
