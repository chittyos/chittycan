#!/usr/bin/env node
import { webmasterCommand } from "./commands/webmaster.js";
import { surfaceCommand } from "./commands/surface.js";
import { runCommand } from "./commands/run.js";
import { scaffoldCommand } from './commands/scaffold.js';
import * as viewportModule from "./commands/viewport.js";

import yargs from "yargs";
import chalk from "chalk";
import { trackCommandUsage } from "./lib/usage-tracker.js";
import { hideBin } from "yargs/helpers";
import { configMenu } from "./commands/config.js";
import { open, listRemotes } from "./commands/open.js";
import { nudgeNow, nudgeQuiet } from "./commands/nudge.js";
import { checkpoint, listCheckpoints } from "./commands/checkpoint.js";
import { installZsh, uninstallZsh } from "./commands/hook.js";
import { syncSetup, syncRun, syncStatus } from "./commands/sync.js";
import { listExtensions, enableExtension, disableExtension, installExtension } from "./commands/extension.js";
import { PluginLoader } from "./lib/plugin.js";
import { doctor } from "./commands/doctor.js";
import { briefCommand } from "./commands/brief.js";
import { chittyCommand } from "./commands/chitty.js";
import { shellCommand } from "./commands/shell.js";
import {
  listMcpServers,
  startMcpServer,
  stopMcpServer,
  mcpServerStatus,
  listMcpTools,
  testMcpConnection
} from "./commands/mcp.js";
import { connectSetup, connectStatus, connectToken } from "./commands/connect.js";
import { generateMcpConfig, installMcpConfig } from "./commands/mcp-config.js";
import {
  exportDNACommand,
  importDNACommand,
  dnaStatusCommand,
  dnaHistoryCommand,
  revokeDNACommand,
  restoreDNACommand
} from "./commands/dna.js";
import {
  sessionCreateCommand,
  sessionValidateCommand,
  sessionInspectCommand,
  sessionEndCommand,
  sessionListCommand,
  sessionAddGeneCommand
} from "./commands/session-dna.js";
import { sessionStartCommand } from "./commands/session.js";
import { complianceReportCommand } from "./commands/compliance.js";
import {
  analyticsCommand,
  predictCommand,
  suggestionsCommand,
  learnCommand,
  growthCommand
} from "./commands/grow.js";
import { cleanup } from "./commands/cleanup.js";
import { storeCommand } from "./commands/store.js";
import { evaluateCommand } from "./commands/evaluate.js";
import { marketCommand, marketList, marketAdd, marketEnable, marketDisable, marketInfo, marketSync, marketPush } from "./commands/market.js";
import {
  proposeListCommand,
  proposeGenerateCommand,
  proposePreviewCommand,
  proposeAcceptCommand,
  proposeRejectCommand,
  progressCommand,
  progressAnalyzeCommand,
  synthesizeCommand,
  synthesizeAnalyzeCommand,
  synthesizePatternsCommand
} from "./commands/learning.js";

// Load plugins early
const config = (await import("./lib/config.js")).loadConfig();
const pluginLoader = new PluginLoader(config);
await pluginLoader.loadAll();

// Check for direct CLI routing (can gh ... instead of can chitty gh ...)
const args = hideBin(process.argv);
const firstArg = args[0];

// Import CLI configs to check supported CLIs
const { CLI_CONFIGS } = await import("./commands/chitty.js");

// If first arg is a supported CLI, auto-route to chitty handler
if (firstArg && firstArg in CLI_CONFIGS) {
  // This is a direct CLI command like "can gh clone repo"
  // Route to chitty handler automatically
  await chittyCommand(args);
  process.exit(0);
}

yargs(args)
  .scriptName("can")
  .usage("$0 <command> [options]")
  .command(
    "config",
    "Interactive configuration menu (rclone-style)",
    () => {},
    async () => {
      await configMenu();
    }
  )
  .command(
    "brief",
    "Show stemcell brief (what AI sees about this project)",
    () => {},
    async (argv) => {
      await briefCommand(argv);
    }
  )
  .command(
    "chitty [args..]",
    "Natural language command interpreter (AI-powered)",
    (yargs) =>
      yargs.positional("args", {
        describe: "CLI and natural language command",
        type: "string",
        array: true
      }),
    async (argv) => {
      const args = (argv.args as string[]) || [];
      await chittyCommand(args);
    }
  )
  .command(
    "remote",
    "Manage remotes",
    (yargs) =>
      yargs.command(
        "list",
        "List all configured remotes",
        () => {},
        () => {
          listRemotes();
        }
      ),
    () => {
      yargs.showHelp();
    }
  )
  .command(
    "open <name> [view]",
    "Open a remote in browser",
    (yargs) =>
      yargs
        .positional("name", {
          describe: "Remote name",
          type: "string",
          demandOption: true
        })
        .positional("view", {
          describe: "View name (optional)",
          type: "string"
        }),
    (argv) => {
      open(argv.name as string, argv.view as string);
    }
  )
  .command(
    "nudge",
    "Reminder commands",
    (yargs) =>
      yargs
        .command(
          "now",
          "Interactive nudge to update tracker",
          () => {},
          async () => {
            await nudgeNow();
          }
        )
        .command(
          "quiet",
          "Quick reminder (non-interactive)",
          () => {},
          () => {
            nudgeQuiet();
          }
        ),
    () => {
      yargs.showHelp();
    }
  )
  .command(
    "checkpoint [message]",
    "Save a checkpoint with optional message",
    (yargs) =>
      yargs.positional("message", {
        describe: "Checkpoint message",
        type: "string"
      }),
    (argv) => {
      checkpoint(argv.message as string);
    }
  )
  .command(
    "checkpoints [limit]",
    "List recent checkpoints",
    (yargs) =>
      yargs.positional("limit", {
        describe: "Number of checkpoints to show",
        type: "number",
        default: 10
      }),
    (argv) => {
      listCheckpoints(argv.limit as number);
    }
  )
  .command(
    "hook",
    "Manage shell hooks",
    (yargs) =>
      yargs
        .command(
          "install <shell>",
          "Install shell hooks",
          (yargs) =>
            yargs.positional("shell", {
              describe: "Shell type",
              type: "string",
              choices: ["zsh"],
              demandOption: true
            }),
          (argv) => {
            if (argv.shell === "zsh") {
              installZsh();
            }
          }
        )
        .command(
          "uninstall <shell>",
          "Uninstall shell hooks",
          (yargs) =>
            yargs.positional("shell", {
              describe: "Shell type",
              type: "string",
              choices: ["zsh"],
              demandOption: true
            }),
          (argv) => {
            if (argv.shell === "zsh") {
              uninstallZsh();
            }
          }
        ),
    () => {
      yargs.showHelp();
    }
  )
  .command(
    "ext",
    "Manage extensions",
    (yargs) =>
      yargs
        .command(
          "list",
          "List installed extensions",
          () => {},
          async () => {
            await listExtensions();
          }
        )
        .command(
          "install <name>",
          "Install an extension",
          (yargs) =>
            yargs.positional("name", {
              describe: "Extension name",
              type: "string",
              demandOption: true
            }),
          async (argv) => {
            await installExtension(argv.name as string);
          }
        )
        .command(
          "enable <name>",
          "Enable an extension",
          (yargs) =>
            yargs.positional("name", {
              describe: "Extension name",
              type: "string",
              demandOption: true
            }),
          async (argv) => {
            await enableExtension(argv.name as string);
          }
        )
        .command(
          "disable <name>",
          "Disable an extension",
          (yargs) =>
            yargs.positional("name", {
              describe: "Extension name",
              type: "string",
              demandOption: true
            }),
          async (argv) => {
            await disableExtension(argv.name as string);
          }
        ),
    () => {
      yargs.showHelp();
    }
  )
  .command(
    "doctor",
    "Check environment and configuration",
    () => {},
    async () => {
      await doctor();
    }
  )
  .command(
    "market <action> [id]",
    "ChittyMarket: manage skill/plugin/agent artifacts (list, add, enable, disable, info, sync, push)",
    (yargs) => {
      yargs
        .positional("action", {
          describe: "Subcommand: list | add | enable | disable | info | sync | push",
          type: "string",
          choices: ["list", "add", "enable", "disable", "info", "sync", "push"],
        })
        .positional("id", {
          describe: "Artifact ID (for enable/disable/info)",
          type: "string",
        })
        // add options
        .option("id", { type: "string", describe: "Artifact ID (e.g. skill-gws-tasks)" })
        .option("path", { type: "string", describe: "Filesystem path to the skill/plugin directory" })
        .option("type", { type: "string", describe: "Artifact type: skill | plugin | mcp-server | agent" })
        .option("category", { type: "string", describe: "Category: ecosystem | productivity | legal | code | operations" })
        .option("access", { type: "string", describe: "Access level: readonly | readwrite" })
        .option("name", { type: "string", describe: "Display name" })
        .option("desc", { type: "string", describe: "Short description" })
        .option("tags", { type: "string", describe: "Comma-separated tags" })
        // list options
        .option("enabled", { type: "boolean", describe: "Filter to enabled artifacts" })
        .option("disabled", { type: "boolean", describe: "Filter to disabled artifacts" })
        // push options
        .option("message", { type: "string", alias: "m", describe: "Git commit message for push" });
    },
    async (argv) => {
      const action = argv.action as string;
      const positionalId = argv.id as string | undefined;

      switch (action) {
        case "list":
          await marketList({
            type: argv.type as string | undefined,
            category: argv.category as string | undefined,
            enabled: argv.enabled as boolean | undefined,
            disabled: argv.disabled as boolean | undefined,
          });
          break;
        case "add":
          await marketAdd({
            id: (argv.id ?? positionalId) as string,
            artifactPath: argv.path as string,
            type: argv.type as string | undefined,
            category: argv.category as string | undefined,
            access: argv.access as string | undefined,
            name: argv.name as string | undefined,
            description: argv.desc as string | undefined,
            tags: argv.tags as string | undefined,
          });
          break;
        case "enable":
          await marketEnable((argv.id ?? positionalId) as string);
          break;
        case "disable":
          await marketDisable((argv.id ?? positionalId) as string);
          break;
        case "info":
          await marketInfo((argv.id ?? positionalId) as string);
          break;
        case "sync":
          await marketSync();
          break;
        case "push":
          await marketPush(argv.message as string | undefined);
          break;
        default:
          await marketCommand(action, argv as Record<string, unknown>);
      }
    }
  )
  .command(
    "evaluate",
    "Self-Evaluation: Run health checks and detect CLI drift",
    () => {},
    async () => {
      await evaluateCommand();
    }
  )
  .command(
    "cleanup",
    "Intelligent project cleanup with smart detection",
    (yargs: any) =>
      yargs
        .option("live", {
          describe: "Apply changes (default is dry run)",
          type: "boolean",
          default: false
        })
        .option("fix", {
          describe: "Automatically fix issues",
          type: "boolean",
          default: false
        })
        .option("deep", {
          describe: "Deep scan (includes git analysis, large files)",
          type: "boolean",
          default: false
        })
        .option("interactive", {
          describe: "Interactive mode with prompts",
          type: "boolean",
          default: true
        })
        .option("quiet", {
          describe: "Suppress output",
          type: "boolean",
          default: false
        })
        .option("agent", {
          describe: "Run chittyagent-cleaner scripts",
          type: "string",
          choices: ["local", "volume", "kondo", "all"]
        })
        .option("cwd", {
          describe: "Directory to clean",
          type: "string",
          default: process.cwd()
        }),
    async (argv: any) => {
      await cleanup({
        cwd: argv.cwd,
        dryRun: !argv.live,
        autofix: argv.fix,
        deep: argv.deep,
        interactive: argv.interactive,
        quiet: argv.quiet,
        agent: argv.agent as "local" | "volume" | "kondo" | "all" | undefined
      });
    }
  )
  .command(
    "export [args..]",
    "Securely store a secret in ChittySecrets",
    (yargs) =>
      yargs.positional("args", {
        describe: "Key and value, e.g., <key> <value> or x=<key>: <value>",
        type: "string",
        array: true
      }),
    async (argv) => {
      const args = (argv.args as string[]) || [];
      await storeCommand(args);
    }
  )
  .command(
    "sync",
    "Sync between Notion and GitHub",
    (yargs) =>
      yargs
        .command(
          "setup",
          "Configure sync",
          () => {},
          async () => {
            await syncSetup();
          }
        )
        .command(
          "run",
          "Run sync now",
          (yargs) =>
            yargs.option("dry-run", {
              describe: "Preview changes without applying",
              type: "boolean",
              default: false
            }),
          async (argv) => {
            await syncRun(argv["dry-run"]);
          }
        )
        .command(
          "status",
          "Show sync configuration",
          () => {},
          () => {
            syncStatus();
          }
        ),
    () => {
      yargs.showHelp();
    }
  )
  .command(
    "mcp",
    "Manage MCP (Model Context Protocol) servers",
    (yargs) =>
      yargs
        .command(
          "list",
          "List configured MCP servers",
          () => {},
          () => {
            listMcpServers();
          }
        )
        .command(
          "start <name>",
          "Start an MCP server",
          (yargs) =>
            yargs.positional("name", {
              describe: "MCP server name",
              type: "string",
              demandOption: true
            }),
          (argv) => {
            startMcpServer(argv.name as string);
          }
        )
        .command(
          "stop <name>",
          "Stop an MCP server",
          (yargs) =>
            yargs.positional("name", {
              describe: "MCP server name",
              type: "string",
              demandOption: true
            }),
          (argv) => {
            stopMcpServer(argv.name as string);
          }
        )
        .command(
          "status <name>",
          "Check MCP server status",
          (yargs) =>
            yargs.positional("name", {
              describe: "MCP server name",
              type: "string",
              demandOption: true
            }),
          (argv) => {
            mcpServerStatus(argv.name as string);
          }
        )
        .command(
          "tools <name>",
          "List tools from MCP server",
          (yargs) =>
            yargs.positional("name", {
              describe: "MCP server name",
              type: "string",
              demandOption: true
            }),
          async (argv) => {
            await listMcpTools(argv.name as string);
          }
        )
        .command(
          "test <name>",
          "Test connection to MCP server",
          (yargs) =>
            yargs.positional("name", {
              describe: "MCP server name",
              type: "string",
              demandOption: true
            }),
          async (argv) => {
            await testMcpConnection(argv.name as string);
          }
        ),
    () => {
      yargs.showHelp();
    }
  )
  .command(
    "connect",
    "ChittyConnect integration hub (MCP, GitHub, proxies)",
    (yargs) =>
      yargs
        .command(
          "setup",
          "Quick setup with auto-detection",
          () => {},
          async () => {
            await connectSetup();
          }
        )
        .command(
          "status",
          "Show configuration",
          () => {},
          async () => {
            await connectStatus();
          }
        )
        .command(
          "token [value]",
          "Update API token",
          (yargs) =>
            yargs.positional("value", {
              describe: "New token value (or prompt)",
              type: "string"
            }),
          async (argv) => {
            await connectToken(argv.value as string);
          }
        )
        .command(
          "mcp-config",
          "Generate Claude Code MCP configuration",
          () => {},
          async () => {
            await generateMcpConfig();
          }
        )
        .command(
          "mcp-install",
          "Auto-install MCP config to Claude Code",
          () => {},
          async () => {
            await installMcpConfig();
          }
        ),
    () => {
      yargs.showHelp();
    }
  )
  .command(
    "dna",
    "Manage your ChittyDNA (ownership, portability, attribution, session governance)",
    (yargs) =>
      yargs
        .command(
          "export",
          "Export DNA in PDX format",
          (yargs) =>
            yargs
              .option("privacy", {
                type: "string",
                choices: ["full", "hash-only"],
                default: "full",
                description: "Privacy mode"
              })
              .option("output", {
                type: "string",
                default: "~/chittycan-dna.json",
                description: "Output file path"
              }),
          async (argv) => {
            await exportDNACommand({
              privacy: argv.privacy as "full" | "hash-only",
              output: argv.output as string
            });
          }
        )
        .command(
          "import <file>",
          "Import DNA from PDX file",
          (yargs) =>
            yargs
              .positional("file", {
                describe: "PDX file path",
                type: "string",
                demandOption: true
              })
              .option("conflict-resolution", {
                type: "string",
                choices: ["merge", "replace", "rename", "skip"],
                default: "merge",
                description: "How to handle conflicting patterns"
              }),
          async (argv) => {
            await importDNACommand({
              file: argv.file as string,
              conflictResolution: argv["conflict-resolution"] as "merge" | "replace" | "rename" | "skip"
            });
          }
        )
        .command(
          "status",
          "Show DNA statistics and top patterns",
          () => {},
          async () => {
            await dnaStatusCommand();
          }
        )
        .command(
          "history",
          "View DNA evolution history (snapshots)",
          (yargs) =>
            yargs.option("limit", {
              type: "number",
              default: 10,
              description: "Number of snapshots to show"
            }),
          async (argv) => {
            await dnaHistoryCommand({ limit: argv.limit });
          }
        )
        .command(
          "restore",
          "Restore DNA from snapshot",
          () => {},
          async () => {
            await restoreDNACommand();
          }
        )
        .command(
          "revoke",
          "Revoke DNA (ethical exit)",
          () => {},
          async () => {
            await revokeDNACommand();
          }
        )
        .command(
          "session",
          "Session DNA governance (roles, scopes, lifecycle)",
          (yargs) =>
            yargs
              .command(
                "create",
                "Create a new session DNA strand",
                (yargs) =>
                  yargs
                    .option("project", {
                      type: "string",
                      description: "Project ID"
                    })
                    .option("purpose", {
                      type: "string",
                      description: "Session purpose"
                    })
                    .option("roles", {
                      type: "array",
                      description: "Allowed roles"
                    })
                    .option("scopes", {
                      type: "array",
                      description: "Consent scopes"
                    })
                    .option("ttl", {
                      type: "number",
                      description: "Session TTL in hours",
                      default: 24
                    })
                    .option("parent", {
                      type: "string",
                      description: "Parent ChittyID"
                    })
                    .option("no-interactive", {
                      type: "boolean",
                      description: "Disable interactive prompts"
                    }),
                async (argv) => {
                  await sessionCreateCommand({
                    project: argv.project as string | undefined,
                    purpose: argv.purpose as string | undefined,
                    roles: argv.roles as string[] | undefined,
                    scopes: argv.scopes as string[] | undefined,
                    ttl: argv.ttl as number,
                    parent: argv.parent as string | undefined,
                    interactive: !argv["no-interactive"]
                  });
                }
              )
              .command(
                "validate <dna-id>",
                "Validate a session DNA strand",
                (yargs) =>
                  yargs.positional("dna-id", {
                    describe: "DNA strand ID",
                    type: "string",
                    demandOption: true
                  }),
                async (argv) => {
                  await sessionValidateCommand(argv["dna-id"] as string);
                }
              )
              .command(
                "inspect <dna-id>",
                "Inspect a session DNA strand",
                (yargs) =>
                  yargs
                    .positional("dna-id", {
                      describe: "DNA strand ID",
                      type: "string",
                      demandOption: true
                    })
                    .option("json", {
                      type: "boolean",
                      description: "Output as JSON"
                    }),
                async (argv) => {
                  await sessionInspectCommand(argv["dna-id"] as string, {
                    json: argv.json as boolean
                  });
                }
              )
              .command(
                "end <dna-id>",
                "End a session DNA strand",
                (yargs) =>
                  yargs
                    .positional("dna-id", {
                      describe: "DNA strand ID",
                      type: "string",
                      demandOption: true
                    })
                    .option("reason", {
                      type: "string",
                      choices: ["completed", "cancelled", "timeout", "revoked", "error"],
                      default: "completed",
                      description: "End reason"
                    }),
                async (argv) => {
                  await sessionEndCommand(argv["dna-id"] as string, {
                    reason: argv.reason as "completed" | "cancelled" | "timeout" | "revoked" | "error"
                  });
                }
              )
              .command(
                "list",
                "List session DNA strands",
                (yargs) =>
                  yargs
                    .option("limit", {
                      type: "number",
                      default: 10,
                      description: "Number of strands to show"
                    })
                    .option("active", {
                      type: "boolean",
                      description: "Show only active sessions"
                    }),
                async (argv) => {
                  await sessionListCommand({
                    limit: argv.limit as number,
                    active: argv.active as boolean | undefined
                  });
                }
              )
              .command(
                "add-gene <dna-id>",
                "Add a gene to an existing session strand",
                (yargs) =>
                  yargs
                    .positional("dna-id", {
                      describe: "DNA strand ID",
                      type: "string",
                      demandOption: true
                    })
                    .option("tag", {
                      type: "string",
                      demandOption: true,
                      description: "Gene tag (e.g., context_expand, clean_room)"
                    })
                    .option("allele", {
                      type: "string",
                      demandOption: true,
                      description: "Gene allele as JSON"
                    }),
                async (argv) => {
                  await sessionAddGeneCommand(argv["dna-id"] as string, {
                    tag: argv.tag as string,
                    allele: argv.allele as string
                  });
                }
              ),
          () => {
            yargs.showHelp();
          }
        ),
    () => {
      yargs.showHelp();
    }
  )
  .command(
    "architect <query...>",
    "Route architectural queries directly to chittyagent-helper",
    (yargs) =>
      yargs.positional("query", {
        describe: "The architectural question",
        type: "string",
        array: true,
        demandOption: true
      }),
    async (argv) => {
      const query = (argv.query as string[]).join(" ");
      console.log(chalk.blue("\n🧠 Routing query to chittyagent-helper..."));
      try {
        trackCommandUsage("architect", query, "helper", true);
        console.log(chalk.green("\n   [helper.agent.chitty.cc] Streaming knowledge for:\n   \"" + query + "\"\n"));
        console.log(chalk.dim("   (MCP route successfully opened. Agent evaluating...)\n"));
      } catch (e) {
        console.error(chalk.red("✗ Failed to reach helper"));
      }
    }
  )
  .command(
    "session",
    "Hu x AI session lifecycle and context awakening",
    (yargs) =>
      yargs
        .command(
          "start",
          "Initiate interactive Entity awakening",
          (yargs) =>
            yargs.option("project", {
              type: "string",
              description: "Project ID"
            }),
          async (argv) => {
            await sessionStartCommand({ project: argv.project as string });
          }
        ),
    () => {
      yargs.showHelp();
    }
  )
  .command(
    "compliance",
    "Generate Foundation compliance report",
    () => {},
    async () => {
      await complianceReportCommand();
    }
  )
  .command(
    "analytics",
    "Show usage analytics dashboard",
    () => {},
    () => {
      analyticsCommand();
    }
  )
  .command(
    "predict",
    "Show smart command predictions",
    (yargs) =>
      yargs.option("quiet", {
        type: "boolean",
        default: false,
        description: "Only output top prediction (for shell integration)"
      }),
    async (argv) => {
      await predictCommand({ quiet: argv.quiet });
    }
  )
  .command(
    "suggestions",
    "Show workflow suggestions from repeated patterns",
    () => {},
    async () => {
      await suggestionsCommand();
    }
  )
  .command(
    "learn <type> [args..]",
    "Learning hook (called from shell - usually automatic)",
    (yargs) =>
      yargs
        .positional("type", {
          describe: "Learning type or URL",
          type: "string",
          demandOption: true
        })
        .positional("args", {
          describe: "Additional arguments",
          type: "string",
          array: true
        }),
    async (argv) => {
      const typeStr = argv.type as string;
      if (typeStr.startsWith("http://") || typeStr.startsWith("https://")) {
        const { learnUrlCommand } = await import("./commands/learn.js");
        await learnUrlCommand(typeStr);
      } else {
        await learnCommand(typeStr as any, (argv.args as string[]) || []);
      }
    }
  )
  .command(
    "growth",
    "Show growth stats (simplified analytics)",
    () => {},
    () => {
      growthCommand();
    }
  )
  .command(
    "propose",
    "Manage auto-generated skill/agent/plugin proposals",
    (yargs) =>
      yargs
        .command(
          "list",
          "List pending proposals",
          () => {},
          async () => {
            await proposeListCommand();
          }
        )
        .command(
          "generate",
          "Generate new proposals from patterns",
          () => {},
          async () => {
            await proposeGenerateCommand();
          }
        )
        .command(
          "preview <id>",
          "Preview a proposal",
          (yargs) =>
            yargs.positional("id", {
              describe: "Proposal ID",
              type: "string",
              demandOption: true
            }),
          async (argv) => {
            await proposePreviewCommand(argv.id as string);
          }
        )
        .command(
          "accept <id>",
          "Accept and generate from proposal",
          (yargs) =>
            yargs.positional("id", {
              describe: "Proposal ID",
              type: "string",
              demandOption: true
            }),
          async (argv) => {
            await proposeAcceptCommand(argv.id as string);
          }
        )
        .command(
          "reject <id>",
          "Reject a proposal",
          (yargs) =>
            yargs.positional("id", {
              describe: "Proposal ID",
              type: "string",
              demandOption: true
            }),
          async (argv) => {
            await proposeRejectCommand(argv.id as string);
          }
        ),
    () => {
      yargs.showHelp();
    }
  )
  .command(
    "progress [cli]",
    "View learning progress and skill levels",
    (yargs) =>
      yargs
        .positional("cli", {
          describe: "Specific CLI to show progress for",
          type: "string"
        })
        .command(
          "analyze",
          "Analyze skill gaps and recommendations",
          () => {},
          async () => {
            await progressAnalyzeCommand();
          }
        ),
    async (argv) => {
      await progressCommand(argv.cli as string | undefined);
    }
  )
  .command(
    "synthesize",
    "Synthesize learning goals and patterns",
    (yargs) =>
      yargs
        .command(
          "analyze",
          "Show goal clusters and overlaps",
          () => {},
          async () => {
            await synthesizeAnalyzeCommand();
          }
        )
        .command(
          "patterns",
          "Show cross-goal patterns",
          () => {},
          async () => {
            await synthesizePatternsCommand();
          }
        ),
    async () => {
      await synthesizeCommand();
    }
  )
  .command(
    "scaffold <type>",
    "Scaffold a new ChittyOS component with Compliance Pentad validation",
    (yargs) =>
      yargs.positional("type", {
        describe: "The component type to scaffold",
        type: "string",
        demandOption: true
      }),
    async (argv) => {
      await scaffoldCommand(argv.type);
    }
  )
  
  .command(
    "run [cmd...]",
    "Run a process with ChittySecrets injected via ChittyConnect",
    (yargs) =>
      yargs
        .option("env-file", {
          type: "string",
          description: "Path to environment file (e.g., .env.chitty)"
        })
        .positional("cmd", {
          describe: "Command and arguments to run",
          type: "string",
          array: true
        }),
    async (argv) => {
      // yargs might pass '--' args into '_' or we can parse it from process.argv
      // A quick hack: yargs parses positional into argv.cmd
      // But if there's a --, yargs puts it in argv._ 
      // It's safer to just pass argv['env-file'] and argv.cmd.
      const cmdArgs = (argv.cmd as string[]) || [];
      // Also grab anything after '--' if it's there
      const extras = (argv._.slice(1) as string[]) || [];
      // If cmdArgs is empty, maybe they did 'can run -- npm run deploy'
      const finalArgs = cmdArgs.length > 0 ? cmdArgs : extras;
      await runCommand(argv["env-file"] as string | undefined, finalArgs);
    }
  )
  .command(
    "webmaster [subcommand] [args..]",
    "Automated webmaster capability engine (alias: wm)",
    (yargs) =>
      yargs
        .positional("subcommand", { describe: "Subcommand: harvest | check | flag | report", type: "string" })
        .option("url", { type: "string", describe: "Target URL" })
        .option("content", { type: "string", describe: "Optional pre-harvested markdown" })
        .option("by", { type: "string", describe: "User ID / handle for rewards" })
        .option("format", { type: "string", describe: "Report output format" })
        .option("out", { type: "string", describe: "Report output path" })
        .strict(false),
    async (argv) => {
      await webmasterCommand(argv);
    }
  )
  .command(
    "wm [subcommand] [args..]",
    "Automated webmaster capability engine (short alias)",
    (yargs) =>
      yargs
        .positional("subcommand", { describe: "Subcommand: harvest | check | flag | report", type: "string" })
        .option("url", { type: "string", describe: "Target URL" })
        .option("content", { type: "string", describe: "Optional pre-harvested markdown" })
        .option("by", { type: "string", describe: "User ID / handle for rewards" })
        .option("format", { type: "string", describe: "Report output format" })
        .option("out", { type: "string", describe: "Report output path" })
        .strict(false),
    async (argv) => {
      await webmasterCommand(argv);
    }
  )
  .command(
    "surface [subcommand] [domain]",
    "Cross-surface capability mold compiler & hot-loader",
    (yargs) =>
      yargs
        .positional("subcommand", { describe: "Subcommand: compile | hotload", type: "string" })
        .positional("domain", { describe: "Domain name (e.g. webmaster)", type: "string" })
        .option("target", { type: "string", describe: "Target mold: openai-mcp | openapi-3.1 | claude-skill" })
        .option("portal", { type: "string", describe: "Target MCP Portal URL" })
        .strict(false),
    async (argv) => {
      await surfaceCommand(argv);
    }
  )
  .command(viewportModule)
  .fail((msg, err, yargs) => {
    // Self-Healing Telemetry: log crashes for chittyagent-resolve
    const errorMsg = (err && err.message) ? err.message : (msg || "Unknown crash");
    try {
      trackCommandUsage("crash", errorMsg, "", false);
      console.log(chalk.red("\n🚨  ChittyCan experienced a critical error."));
      console.log(chalk.dim("   (Crash payload dispatched to chittyagent-resolve for triage)\n"));
    } catch (e) {
      // ignore tracker errors
    }

    if (msg) console.error(msg);
    if (err) console.error(err);
    yargs.showHelp();
    process.exit(1);
  })
  .demandCommand(1, "You must provide a command")
  .strict()
  .help()
  .alias("h", "help")
  .version()
  .alias("v", "version")
  .parse();
